import React,{Component} from "react";

class Hotelcontact extends Component
{
    render()
    {
        return(
            <div>
                <h3>Hotel Contact Details :</h3>
                <ul>
                    <li>Mobile No : +91 740618XXX</li>
                    <li>Email     : hotelify@gmail.com</li>
                    <li>Location  : Pune, Maharastra</li>
                </ul>
            </div>
        )
    }
}

export default Hotelcontact;