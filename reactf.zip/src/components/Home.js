import React,{Component} from 'react';

class Home extends Component{
    render(){
        return(
            <div>
                <h1>Header</h1>
                <h3><a href="/header">Click here</a></h3>
            </div>
        )
    }
}
export default Home;